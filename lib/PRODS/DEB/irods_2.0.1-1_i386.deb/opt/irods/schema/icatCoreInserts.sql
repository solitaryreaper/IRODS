/* 
The value '1170000000' is the Unix time (seconds since 1970,
quasi-universal time) for an arbitrary recent past time
(2007-01-28 08:00:00).
*/
insert into RCORE_SCHEMAS values ('rcat','RODS metadata catalog',0,'','1170000000','1170000000');

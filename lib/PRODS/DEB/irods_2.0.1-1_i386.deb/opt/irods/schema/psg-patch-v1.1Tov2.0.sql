-- run these SQL, using postgresql client psql 

alter table R_DATA_MAIN add column data_mode varchar(32);

-- run these SQL, using Oracle client sqlplus

alter table R_DATA_MAIN add data_mode varchar(32);
exit;

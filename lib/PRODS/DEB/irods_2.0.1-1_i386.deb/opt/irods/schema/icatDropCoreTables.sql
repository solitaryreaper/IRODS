drop table RCORE_SCHEMAS;
drop table RCORE_TABLES;
drop table RCORE_ATTRIBUTES;
drop table RCORE_FK_RELATIONS;
drop table RCORE_USER_SCHEMAS;
drop table RCORE_USCHEMA_ATTR;
